const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { authenticateToken, JWT_SECRET } = require("../middleware/auth");

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD = 6;

function makeToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}
function publicUser(row) {
  return { id: row.id, fullName: row.full_name, email: row.email };
}
function findByEmail(email) {
  return db.prepare("SELECT * FROM users WHERE lower(email) = ?").get(email);
}

// ─── REGISTER ────────────────────────────────────────────────────────────────
router.post("/register", async (req, res) => {
  const fullName = String(req.body.fullName || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (!fullName || !email || !password) {
    return res.status(400).json({ error: "fullName, email, and password are required" });
  }
  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: "Please enter a valid email address" });
  }
  if (password.length < MIN_PASSWORD) {
    return res.status(400).json({ error: `Password must be at least ${MIN_PASSWORD} characters` });
  }
  if (findByEmail(email)) {
    return res.status(409).json({ error: "Email already registered" });
  }

  const hashed = await bcrypt.hash(password, 10);
  const result = db.prepare(
    "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)"
  ).run(fullName, email, hashed);

  // Every new user starts with an empty budget row (and no bunnies).
  db.prepare("INSERT OR IGNORE INTO budgets (user_id) VALUES (?)").run(result.lastInsertRowid);

  const user = { id: Number(result.lastInsertRowid), full_name: fullName, email };
  res.status(201).json({
    message: "Account created successfully",
    token: makeToken(user),
    user: publicUser(user)
  });
});

// ─── LOGIN ───────────────────────────────────────────────────────────────────
router.post("/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (!email || !password) {
    return res.status(400).json({ error: "email and password are required" });
  }

  const user = findByEmail(email);
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  res.json({ message: "Login successful", token: makeToken(user), user: publicUser(user) });
});

// ─── GET PROFILE ─────────────────────────────────────────────────────────────
router.get("/me", authenticateToken, (req, res) => {
  const user = db.prepare("SELECT id, full_name, email, created_at FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ id: user.id, fullName: user.full_name, email: user.email, createdAt: user.created_at });
});

// ─── UPDATE PROFILE (name / email) ───────────────────────────────────────────
router.put("/profile", authenticateToken, (req, res) => {
  const current = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  if (!current) return res.status(404).json({ error: "User not found" });

  const fullName = req.body.fullName !== undefined ? String(req.body.fullName).trim() : current.full_name;
  const email = req.body.email !== undefined ? String(req.body.email).trim().toLowerCase() : current.email;

  if (!fullName) return res.status(400).json({ error: "Name cannot be empty" });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: "Please enter a valid email address" });

  const clash = findByEmail(email);
  if (clash && clash.id !== current.id) {
    return res.status(409).json({ error: "That email is already used by another account" });
  }

  db.prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?").run(fullName, email, current.id);

  const updated = { id: current.id, full_name: fullName, email };
  // The email is stored inside the token, so hand back a fresh one.
  res.json({ message: "Profile updated", token: makeToken(updated), user: publicUser(updated) });
});

// ─── CHANGE PASSWORD ─────────────────────────────────────────────────────────
router.put("/change-password", authenticateToken, async (req, res) => {
  const currentPassword = String(req.body.currentPassword || "");
  const newPassword = String(req.body.newPassword || "");

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: "currentPassword and newPassword are required" });
  }
  if (newPassword.length < MIN_PASSWORD) {
    return res.status(400).json({ error: `New password must be at least ${MIN_PASSWORD} characters` });
  }

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  const valid = await bcrypt.compare(currentPassword, user.password);
  // 400 (not 401) on purpose: a wrong password here must NOT look like an expired session.
  if (!valid) return res.status(400).json({ error: "Current password is incorrect" });

  const hashed = await bcrypt.hash(newPassword, 10);
  db.prepare("UPDATE users SET password = ? WHERE id = ?").run(hashed, req.user.id);
  res.json({ message: "Password updated successfully" });
});

// ─── DELETE ACCOUNT ──────────────────────────────────────────────────────────
// ON DELETE CASCADE removes the user's expenses, budget and bunnies too.
router.delete("/account", authenticateToken, (req, res) => {
  db.prepare("DELETE FROM users WHERE id = ?").run(req.user.id);
  res.json({ message: "Account deleted successfully" });
});

module.exports = router;
